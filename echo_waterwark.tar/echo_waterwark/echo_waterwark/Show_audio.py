import numpy as np
import matplotlib.pyplot as plt

def plot_audio(audio_data, framerate, title, filename):
    time = np.linspace(0, len(audio_data) / framerate, num=len(audio_data))
    plt.figure(figsize=(10, 4))
    plt.plot(time, audio_data)
    plt.title(title)
    plt.xlabel('Time [s]')
    plt.ylabel('Amplitude')
    plt.grid(True)
    plt.savefig(filename)  # Lưu biểu đồ dưới dạng tệp hình ảnh

if __name__ == "__main__":
    # Load original audio data
    audio_data = np.load('audio_data.npy')
    framerate = np.load('framerate.npy').item()  # Convert framerate to integer

    # Plot original audio
    plot_audio(audio_data, framerate, 'Original Audio', 'original_audio.png')

    # Load watermarked audio data
    watermarked_audio = np.load('watermarked_audio.npy')

    # Plot watermarked audio
    plot_audio(watermarked_audio, framerate, 'Watermarked Audio', 'watermarked_audio.png')

    # Save plots instead of showing them
    plt.tight_layout()

