import wave
import numpy as np

def save_audio(filename, audio_data, framerate):
    framerate = int(framerate)  # Chuyển đổi framerate thành số nguyên
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(framerate)
        wf.writeframes(audio_data.tobytes())

if __name__ == "__main__":
    watermarked_audio = np.load('watermarked_audio.npy')
    framerate = np.load('framerate.npy')
    save_audio('watermarked.wav', watermarked_audio, framerate)
