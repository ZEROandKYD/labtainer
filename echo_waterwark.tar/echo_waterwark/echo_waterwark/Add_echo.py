# add_echo.py
import numpy as np

def add_echo(audio_data, delay, attenuation):
    echo_data = np.zeros_like(audio_data)
    echo_data[delay:] = audio_data[:-delay] * attenuation
    return audio_data + echo_data

if __name__ == "__main__":
    audio_data = np.load('audio_data.npy')
    framerate = np.load('framerate.npy')
    delay = int(framerate * 0.2)  # Độ trễ 200ms
    attenuation = 0.5
    watermarked_audio = add_echo(audio_data, delay, attenuation)
    np.save('watermarked_audio.npy', watermarked_audio)
